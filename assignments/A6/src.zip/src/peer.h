#pragma once
#include "common.h"

#define MAIN_ARGNUM     2   // number of command line arguments to main().
