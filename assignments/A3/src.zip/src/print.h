#include "support.h"
#include "wires.h"

void print_ctrl(bool runs, bool is_valid); 

void print_decoded(val major_op, val minor_op);
